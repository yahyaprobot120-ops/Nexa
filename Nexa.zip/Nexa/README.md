# Nexa Android — starter prototype

An original dark community/chat app prototype built with Kotlin and Jetpack Compose.

## Current status
- Native Android Compose UI scaffold
- Home, community/channel selector, local demo chat, friends and profile screens
- GitHub Actions workflow to build a debug APK

## Important limitations
This is a UI prototype. Messages are local in-memory demo data only. Authentication, cloud sync, uploads, push notifications, moderation backend, voice/video and screen sharing are NOT implemented yet. Do not use it for real accounts or private conversations.

## Build on Android only
1. Create a GitHub repository and upload this project folder.
2. Open the repository's Actions tab and enable GitHub Actions.
3. Run the `Build Nexa APK` workflow.
4. Download the `Nexa-debug-apk` artifact from the completed workflow run.
5. Install the APK on your Android device. Android may ask you to allow installation from the browser/files app.

## Build locally
Requires JDK 17 and Android SDK 35:
`gradle :app:assembleDebug`

## Next engineering steps
1. Add Firebase project configuration and secure Firestore rules.
2. Implement Firebase Authentication and user profiles.
3. Implement Firestore-backed communities, membership, channels and messages.
4. Add Storage uploads with file-size/type validation.
5. Add FCM notifications.
6. Integrate LiveKit with server-issued short-lived room tokens. Never embed service secrets in the APK.
7. Add tests, accessibility checks and privacy review.
