package com.nexa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF191B23)
private val Panel2 = Color(0xFF222530)
private val Accent = Color(0xFF7587FF)
private val TextMain = Color(0xFFF5F6FA)
private val Muted = Color(0xFF9BA1B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexaApp() }
    }
}

private enum class Tab(val title: String) { HOME("الرئيسية"), MESSAGES("الرسائل"), FRIENDS("الأصدقاء"), PROFILE("حسابي") }

@Composable
private fun NexaApp() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var selectedCommunity by remember { mutableStateOf("Nexa Community") }
    var selectedChannel by remember { mutableStateOf("عام") }
    var message by remember { mutableStateOf("") }
    var sentMessages by remember { mutableStateOf(listOf("مرحباً بك في Nexa!", "هذه نسخة تجريبية للواجهة.")) }
    var showCreate by remember { mutableStateOf(false) }
    var communityName by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onBackground = TextMain, onSurface = TextMain)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = TextMain) {
                listOf(Icons.Default.Home, Icons.Default.ChatBubble, Icons.Default.People, Icons.Default.Person).forEachIndexed { index, icon ->
                    val item = Tab.entries[index]
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Icon(icon, contentDescription = item.title) }, label = { Text(item.title, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Bg)) {
                Header(tab.title)
                when (tab) {
                    Tab.HOME -> HomeScreen(selectedCommunity, selectedChannel, onCommunity = { selectedCommunity = it }, onChannel = { selectedChannel = it }, onCreate = { showCreate = true }, onOpenChat = { tab = Tab.MESSAGES })
                    Tab.MESSAGES -> ChatScreen(message, { message = it }, sentMessages, { if (message.isNotBlank()) { sentMessages = sentMessages + message.trim(); message = "" } })
                    Tab.FRIENDS -> FriendsScreen()
                    Tab.PROFILE -> ProfileScreen()
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, title = { Text("إنشاء مجتمع") }, text = { OutlinedTextField(value = communityName, onValueChange = { communityName = it }, label = { Text("اسم المجتمع") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (communityName.isNotBlank()) selectedCommunity = communityName.trim(); communityName = ""; showCreate = false }) { Text("إنشاء") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("إلغاء") } }, containerColor = Panel)
    }
}

@Composable private fun Header(title: String) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(Accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text("N", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) { Text("NEXA", color = TextMain, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp); Text(title, color = Muted, fontSize = 11.sp) }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, contentDescription = "الإشعارات", tint = Muted) }
    }
}

@Composable private fun HomeScreen(community: String, channel: String, onCommunity: (String) -> Unit, onChannel: (String) -> Unit, onCreate: () -> Unit, onOpenChat: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("مساحاتك", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("مجتمعاتك وقنواتك في مكان واحد", color = Muted, fontSize = 13.sp) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { CommunityTile("N", "Nexa Community", community == "Nexa Community", Modifier.weight(1f)) { onCommunity("Nexa Community") }; CommunityTile("G", "Gaming Hub", community == "Gaming Hub", Modifier.weight(1f)) { onCommunity("Gaming Hub") } } }
        item { OutlinedButton(onClick = onCreate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إنشاء مجتمع جديد") } }
        item { Text(community, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(listOf("عام", "الألعاب", "الإعلانات", "الصور")) { name -> ChannelRow(name, channel == name) { onChannel(name) } }
        item { Card(Modifier.fillMaxWidth().clickable { onOpenChat() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text("ابدأ محادثة", color = TextMain, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text("افتح مساحة الرسائل وجرب إرسال رسالة محلية", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Text("فتح الرسائل  →", color = Accent, fontWeight = FontWeight.SemiBold) } } }
    }
}

@Composable private fun CommunityTile(letter: String, name: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF292F4B) else Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(13.dp)) { Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text(letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }; Spacer(Modifier.height(9.dp)); Text(name, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp) } }
}

@Composable private fun ChannelRow(name: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(if (selected) Panel2 else Panel, RoundedCornerShape(13.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text("#", color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(12.dp)); Text(name, color = TextMain, modifier = Modifier.weight(1f)); if (selected) Icon(Icons.Default.Check, null, tint = Accent) }
}

@Composable private fun ChatScreen(value: String, onValue: (String) -> Unit, messages: List<String>, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("# عام", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 19.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.Search, null, tint = Muted) }
        Text("هذه محادثة تجريبية على الجهاز", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg -> Row(verticalAlignment = Alignment.Top) { Box(Modifier.size(34.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) { Text("N", color = Color.White, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f).background(Panel, RoundedCornerShape(13.dp)).padding(11.dp)) { Text("Nexa Bot", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(msg, color = TextMain, fontSize = 14.sp) } } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.weight(1f), placeholder = { Text("اكتب رسالة...") }, shape = RoundedCornerShape(16.dp), singleLine = true); Spacer(Modifier.width(8.dp)); IconButton(onClick = onSend, modifier = Modifier.background(Accent, CircleShape)) { Icon(Icons.Default.Send, null, tint = Color.White) } }
    }
}

@Composable private fun FriendsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text("الأصدقاء", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("قائمة تجريبية إلى أن نربط الحسابات", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(18.dp)); listOf("PlayerOne", "MoonLight", "CraftMaster").forEach { name -> Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Accent) }; Spacer(Modifier.width(12.dp)); Text(name, color = TextMain, modifier = Modifier.weight(1f)); Text("متصل", color = Color(0xFF55C994), fontSize = 11.sp) } } }
}

@Composable private fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Spacer(Modifier.height(30.dp)); Box(Modifier.size(92.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) { Text("N", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black) }; Spacer(Modifier.height(14.dp)); Text("مستخدم Nexa", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 21.sp); Text("@new_user", color = Muted); Spacer(Modifier.height(26.dp)); listOf("تعديل الملف الشخصي", "الخصوصية والأمان", "الإشعارات", "المظهر واللغة", "حول Nexa  •  الإصدار 0.1.0").forEach { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(13.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Text(it, color = TextMain, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
}
